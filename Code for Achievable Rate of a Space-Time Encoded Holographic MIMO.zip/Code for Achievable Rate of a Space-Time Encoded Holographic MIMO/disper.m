function [x]=disper(S)
x=S*(S+2)*log2(exp(1)^2)/(2*(S+1)^2);



