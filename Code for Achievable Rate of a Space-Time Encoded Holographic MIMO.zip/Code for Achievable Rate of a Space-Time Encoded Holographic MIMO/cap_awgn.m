function C = cap_awgn(P)
C = 1/2 * log2(1 + P);
